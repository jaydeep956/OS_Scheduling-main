# Process Scheduling Algorithms
This project implements three popular algorithms for process scheduling - Banker's, Binary Semaphore and counting semaphore.

Bootstrap (5.0), javascript and basic HTML, CSS was used.
